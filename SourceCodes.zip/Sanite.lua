if game:WaitForChild("Players").LocalPlayer:WaitForChild("PlayerGui") then
    local args = {"SetTeam", "Pirates"}
    game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("CommF_"):InvokeServer(unpack(args))
end

local saniteversion = "Release 1.0"
local Fluent = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()
local speaker = game.Players.LocalPlayer
local character = speaker.Character or speaker.CharacterAdded:Wait()
local backpack = speaker:WaitForChild("Backpack")
local collectFruits = {}
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")
local HttpService = game:GetService("HttpService")
local TeleportService = game:GetService("TeleportService")
local Alreadystored = {}

makefolder("Sanite")

local function updatefile(filename)
    local filePath = "Sanite/" .. filename .. ".txt"
    local current = 0
    if isfile(filePath) then
        current = tonumber(readfile(filePath)) or 0
    end
    current = current + 1
    writefile(filePath, tostring(current))
    return current
end

local function getFile(filename)
    local filePath = "Sanite/" .. filename .. ".txt"
    if not isfile(filePath) then return nil end
    return readfile(filePath)
end

local function serverhop()
    local servers = {}
    local req = game:HttpGet("https://games.roblox.com/v1/games/" .. game.PlaceId .. "/servers/Public?sortOrder=Desc&limit=100&excludeFullGames=true")
    local body = HttpService:JSONDecode(req)

    if body and body.data then
        for _, v in ipairs(body.data) do
            if type(v) == "table" and v.playing and v.maxPlayers and v.playing < v.maxPlayers and v.id ~= game.JobId then
                table.insert(servers, v.id)
            end
        end
    end

    if #servers > 0 then
        local success, err = pcall(function()
            TeleportService:TeleportToPlaceInstance(game.PlaceId, servers[math.random(1, #servers)], speaker)
        end)

        if not success then
            Fluent:Notify({Title = "Server Hop Failed", Content = "Failed to teleport. Retrying...", Duration = 3})
            task.wait(2)
            serverhop()
        else
            task.wait(5)
            serverhop()
        end
    else
        Fluent:Notify({Title = "Server Hop", Content = "No available servers found. Retrying...", Duration = 3})
        task.wait(1)
        serverhop()
    end
end

if game.GameId ~= 994732206 then
    Fluent:Notify({Title = "Error!", Content = "You are not in Blox Fruits!", SubContent = "Script terminated.", Duration = 5})
    script:Destroy()
end

local Window = Fluent:CreateWindow({
    Title = "Sanite",
    SubTitle = "Fruit Farmer for Blox Fruits",
    TabWidth = 160,
    Size = UDim2.fromOffset(580, 460),
    Acrylic = true,
    Theme = "Aqua",
    MinimizeKey = Enum.KeyCode.LeftControl
})

local Tabs = {
    Main = Window:AddTab({ Title = "Sanite", Icon = "aperture" })
}

Tabs.Main:AddParagraph({
    Title = "Sanite " .. saniteversion,
    Content = "Stats:\nTime spent: " .. (getFile("time") or "0") .. "s\nFruits collected: " .. (getFile("fruits") or "0") .. "\nServers hopped: " .. (getFile("servers") or "0")
})

task.spawn(function()
    while true do
        wait(1)
        updatefile("time")
    end
end)

local function isFruit(model)
    if model:IsA("Model") or model:IsA("Tool") then
        local name = model.Name:lower()
        if name:find("fruit") then
            if model:IsA("Model") then
                return model:FindFirstChild("Handle") ~= nil
            else
                return true
            end
        end
    end
    return false
end

local function scanForFruits()
    local foundFruits = 0
    for _, child in ipairs(Workspace:GetChildren()) do
        if isFruit(child) and not table.find(collectFruits, child) then
            table.insert(collectFruits, child)
            foundFruits = foundFruits + 1
            Fluent:Notify({Title = "Fruit Found", Content = "Added: " .. child.Name .. " (" .. child.ClassName .. ")", Duration = 1})
        end
    end

    if foundFruits > 0 then
        Fluent:Notify({Title = "Fruits Found", Content = "Added " .. foundFruits .. " fruits to queue", Duration = 2})
    else
        Fluent:Notify({Title = "Scan Complete", Content = "No new fruits found", Duration = 1})
    end
    return foundFruits
end

local function pickupFruitTools()
    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
    if not humanoid then return end

    local pickedUp = false
    for _, child in ipairs(Workspace:GetChildren()) do
        if isFruit(child) and child:IsA("Tool") then
            humanoid:EquipTool(child)
            pickedUp = true
            task.wait(0.1)
        end
    end

    if pickedUp then
        Fluent:Notify({Title = "Tools Picked Up", Content = "Picked up fruit tools in workspace", Duration = 1})
    end
end

local grabToolsFunc
local function setupToolGrabber()
    if grabToolsFunc then
        grabToolsFunc:Disconnect()
    end

    grabToolsFunc = Workspace.ChildAdded:Connect(function(child)
        if isFruit(child) and child:IsA("Tool") then
            local humanoid = character:FindFirstChildWhichIsA("Humanoid")
            if humanoid then
                humanoid:EquipTool(child)
                Fluent:Notify({Title = "Tool Picked Up", Content = "Picked up: " .. child.Name, Duration = 1})
            end
        end
    end)
end

local storedFruits = {}

local function autostore()
    while true do
        task.wait(1)
        for _, tool in ipairs(backpack:GetChildren()) do
            if isFruit(tool) then
                local fruitName = tool.Name:gsub("fruit", ""):gsub("Fruit", ""):gsub(" ", "")
                if fruitName == "" then fruitName = tool.Name end
                if not storedFruits[tool] then
                    local success, result = pcall(function()
                        return ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("CommF_"):InvokeServer(
                            "StoreFruit",
                            fruitName .. "-" .. fruitName,
                            tool
                        )
                    end)
                    if success and result then
                        Fluent:Notify({Title = "Stored Fruit", Content = "Stored: " .. tool.Name, Duration = 1})
                        updatefile("fruits")
                        storedFruits[tool] = true
                    else
                        Fluent:Notify({Title = "Store Error", Content = "Failed to store: " .. tool.Name, Duration = 2})
                        tool:Destroy()
                    end
                else
                    Fluent:Notify({Title = "Duplicate Fruit", Content = "Destroying already stored fruit: " .. tool.Name, Duration = 1})
                    tool:Destroy()
                end
            end
        end
        if character then
            for _, tool in ipairs(character:GetChildren()) do
                if isFruit(tool) then
                    local fruitName = tool.Name:gsub("fruit", ""):gsub("Fruit", ""):gsub(" ", "")
                    if fruitName == "" then fruitName = tool.Name end
                    if not storedFruits[tool] then
                        local success, result = pcall(function()
                            return ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("CommF_"):InvokeServer(
                                "StoreFruit",
                                fruitName .. "-" .. fruitName,
                                tool
                            )
                        end)
                        if success and result then
                            Fluent:Notify({Title = "Stored Fruit", Content = "Stored: " .. tool.Name, Duration = 1})
                            updatefile("fruits")
                            storedFruits[tool] = true
                        else
                            Fluent:Notify({Title = "Store Error", Content = "Failed to store: " .. tool.Name, Duration = 2})
                            tool:Destroy()
                        end
                    else
                        Fluent:Notify({Title = "Duplicate Fruit", Content = "Destroying already stored fruit: " .. tool.Name, Duration = 1})
                        tool:Destroy()
                    end
                end
            end
        end
    end
end

local function tweenToFruit(fruitModel)
    if not fruitModel or not fruitModel:FindFirstChild("Handle") then
        Fluent:Notify({Title = "Debug", Content = "Invalid fruit model!", Duration = 2})
        return false
    end

    local rootPart = character:FindFirstChild("HumanoidRootPart")
    if not rootPart then
        Fluent:Notify({Title = "Debug", Content = "HumanoidRootPart missing!", Duration = 2})
        return false
    end

    Fluent:Notify({Title = "Moving", Content = "Tweening to " .. fruitModel.Name .. "'s Handle", Duration = 2})

    -- Anchor root part during tween
    local wasAnchored = rootPart.Anchored
    rootPart.Anchored = true

    -- Calculate distance and tween time (250 studs/second)
    local distance = (fruitModel.Handle.Position - rootPart.Position).Magnitude
    local speed = 250
    local tweenTime = distance / speed

    -- Create tween directly to the Handle's position
    local tweenInfo = TweenInfo.new(
        tweenTime,
        Enum.EasingStyle.Linear,
        Enum.EasingDirection.Out,
        0,
        false
    )

    -- Tween directly to the Handle's CFrame
    local tween = TweenService:Create(rootPart, tweenInfo, {
        CFrame = fruitModel.Handle.CFrame
    })

    tween:Play()

    -- Check if fruit still exists during tween
    local fruitStillExists = true
    local connection
    connection = RunService.Heartbeat:Connect(function()
        if not fruitModel:IsDescendantOf(Workspace) or not fruitModel:FindFirstChild("Handle") then
            fruitStillExists = false
        end
    end)

    -- Wait for tween to complete or fruit to disappear
    repeat
        task.wait(0.1)
    until not fruitStillExists or tween.PlaybackState == Enum.PlaybackState.Completed

    -- Clean up connection
    if connection then
        connection:Disconnect()
    end

    -- If fruit still exists, spin for 5 seconds to ensure pickup
    if fruitStillExists then
        Fluent:Notify({Title = "Spinning", Content = "Spinning at fruit location for 5 seconds", Duration = 2})
        rootPart.Anchored = false
        local startTime = os.time()
        local humanoid = character:FindFirstChildWhichIsA("Humanoid")

        while os.time() - startTime < 5 and fruitStillExists do
            if rootPart and fruitModel.Handle then
                -- Spin the character around the fruit
                local angle = (os.time() - startTime) * 2 * math.pi / 5  -- Complete 1 rotation every 5 seconds
                local offset = Vector3.new(math.cos(angle) * 2, 0, math.sin(angle) * 2)
                rootPart.CFrame = CFrame.new(fruitModel.Handle.Position + offset, fruitModel.Handle.Position)
            end
            task.wait(0.1)

            -- Check if fruit still exists
            if not fruitModel:IsDescendantOf(Workspace) or not fruitModel:FindFirstChild("Handle") then
                fruitStillExists = false
            end
        end
    end

    -- Restore anchor state
    rootPart.Anchored = wasAnchored

    return fruitStillExists
end

local function processFruits()
    while true do
        pickupFruitTools()

        if #collectFruits > 0 then
            local fruit = collectFruits[1]
            if fruit and fruit:FindFirstChild("Handle") and fruit:IsDescendantOf(Workspace) then
                if isFruit(fruit) and fruit:IsA("Model") then
                    Fluent:Notify({Title = "Tweening", Content = "Moving to " .. fruit.Name .. "'s Handle", Duration = 1})
                    local fruitStillExists = tweenToFruit(fruit)
                    if not fruitStillExists then
                        Fluent:Notify({Title = "Fruit Picked Up", Content = "Fruit was picked up during tween", Duration = 1})
                    end
                    table.remove(collectFruits, 1)
                else
                    table.remove(collectFruits, 1)
                    Fluent:Notify({Title = "Fruit Changed", Content = "Fruit became a tool or disappeared", Duration = 1})
                end
            else
                table.remove(collectFruits, 1)
            end
        else
            if scanForFruits() == 0 then
                local startTime = os.time()
                repeat
                    task.wait(1)
                    if scanForFruits() > 0 then
                        break
                    end
                until os.time() - startTime >= 10

                if scanForFruits() == 0 then
                    Fluent:Notify({Title = "Server Hop", Content = "No fruits found for 10 seconds. Hopping servers...", Duration = 3})
                    updatefile("servers")
                    serverhop()
                end
            end
            task.wait(5)
        end
    end
end

Workspace.ChildAdded:Connect(function(child)
    if isFruit(child) and not table.find(collectFruits, child) then
        table.insert(collectFruits, child)
        Fluent:Notify({Title = "New Fruit", Content = "Detected: " .. child.Name .. " (" .. child.ClassName .. ")", Duration = 1})
    end
end)

task.spawn(function()
    while true do
        scanForFruits()
        task.wait(10)
    end
end)

task.spawn(processFruits)
task.spawn(autostore)
setupToolGrabber()

local VirtualUser = game:GetService("VirtualUser")
game:GetService("Players").LocalPlayer.Idled:connect(function()
    VirtualUser:Button2Down(Vector2.new(0,0), workspace.CurrentCamera.CFrame)
    task.wait(1)
    VirtualUser:Button2Up(Vector2.new(0,0), workspace.CurrentCamera.CFrame)
end)

speaker.CharacterAdded:Connect(function(newCharacter)
    character = newCharacter
    character:WaitForChild("HumanoidRootPart")
    setupToolGrabber()
end)

local function debugWorkspace()
    local output = "=== WORKSPACE DEBUG ===\n"
    local fruitModels = 0
    local fruitTools = 0
    local otherItems = 0

    output = output .. "\n--- ALL WORKSPACE ITEMS ---\n"
    for _, child in ipairs(Workspace:GetChildren()) do
        if isFruit(child) then
            if child:IsA("Model") then
                fruitModels = fruitModels + 1
                output = output .. "🍎 FRUIT MODEL: " .. child.Name .. "\n"
                output = output .. "   Class: " .. child.ClassName .. "\n"
                output = output .. "   Position: " .. tostring(child:GetPivot().Position) .. "\n"
                if child:FindFirstChild("Handle") then
                    output = output .. "   Handle Position: " .. tostring(child.Handle.Position) .. "\n"
                end
            else
                fruitTools = fruitTools + 1
                output = output .. "🍒 FRUIT TOOL: " .. child.Name .. "\n"
                output = output .. "   Class: " .. child.ClassName .. "\n"
                output = output .. "   Position: " .. tostring(child:GetPivot().Position) .. "\n"
            end
        else
            otherItems = otherItems + 1
            output = output .. "📦 OTHER: " .. child.Name .. " (" .. child.ClassName .. ")\n"
        end
    end

    output = output .. "\n--- SUMMARY ---\n"
    output = output .. "Fruit Models: " .. fruitModels .. "\n"
    output = output .. "Fruit Tools: " .. fruitTools .. "\n"
    output = output .. "Other Items: " .. otherItems .. "\n"

    print(output)
    Fluent:Notify({Title = "Workspace Debug", Content = "Fruits: " .. fruitModels .. " models, " .. fruitTools .. " tools\nCheck console for full details", Duration = 10})
end

Tabs.Main:AddButton({Title = "Server Hop", Description = "Manually hop to a new server", Callback = function() updatefile("servers") serverhop() end})
Tabs.Main:AddButton({Title = "Debug Workspace", Description = "Show ALL workspace contents", Callback = function() debugWorkspace() end})
Tabs.Main:AddButton({Title = "Rescan for Fruits", Description = "Force rescan workspace", Callback = function()
    local found = scanForFruits()
    if found == 0 then
        Fluent:Notify({Title = "Rescan", Content = "No fruits found", Duration = 2})
    end
end})