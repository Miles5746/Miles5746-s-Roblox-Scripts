local players = game:GetService("Players")
local player = players.LocalPlayer
local uis = game:GetService("UserInputService")

local character = player.Character or player.CharacterAdded:Wait()
local hrp = character:WaitForChild("HumanoidRootPart")

local enabled = false
local cooldown = 0.5
local teleportRange = 10

local screenGui = Instance.new("ScreenGui")
screenGui.Name = "TeleportGui"
screenGui.ResetOnSpawn = false
screenGui.Parent = game:GetService("CoreGui")

local mainFrame = Instance.new("Frame")
mainFrame.Size = UDim2.new(0, 250, 0, 200)
mainFrame.Position = UDim2.new(0.5, -125, 0.5, -100)
mainFrame.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
mainFrame.BorderSizePixel = 2
mainFrame.BorderColor3 = Color3.fromRGB(255, 255, 255)
mainFrame.Parent = screenGui

local drag = Instance.new("UIDragDetector")
drag.Parent = mainFrame

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, 0, 0, 30)
title.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
title.Text = "Miles5746's TP Aura'"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.TextScaled = true
title.Font = Enum.Font.GothamBold
title.Parent = mainFrame

local toggleBtn = Instance.new("TextButton")
toggleBtn.Size = UDim2.new(0.8, 0, 0, 35)
toggleBtn.Position = UDim2.new(0.1, 0, 0, 40)
toggleBtn.BackgroundColor3 = Color3.fromRGB(255, 50, 50)
toggleBtn.Text = "OFF"
toggleBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
toggleBtn.TextScaled = true
toggleBtn.Font = Enum.Font.GothamBold
toggleBtn.Parent = mainFrame

local cooldownLabel = Instance.new("TextLabel")
cooldownLabel.Size = UDim2.new(0.8, 0, 0, 25)
cooldownLabel.Position = UDim2.new(0.1, 0, 0, 85)
cooldownLabel.BackgroundTransparency = 1
cooldownLabel.Text = "Cooldown: " .. cooldown .. "s"
cooldownLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
cooldownLabel.TextScaled = true
cooldownLabel.Font = Enum.Font.Gotham
cooldownLabel.Parent = mainFrame

local cooldownSlider = Instance.new("TextButton")
cooldownSlider.Size = UDim2.new(0.8, 0, 0, 20)
cooldownSlider.Position = UDim2.new(0.1, 0, 0, 115)
cooldownSlider.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
cooldownSlider.Text = ""
cooldownSlider.Parent = mainFrame

local cooldownFill = Instance.new("Frame")
cooldownFill.Size = UDim2.new(0.5, 0, 1, 0)
cooldownFill.BackgroundColor3 = Color3.fromRGB(100, 200, 255)
cooldownFill.BorderSizePixel = 0
cooldownFill.Parent = cooldownSlider

local rangeLabel = Instance.new("TextLabel")
rangeLabel.Size = UDim2.new(0.8, 0, 0, 25)
rangeLabel.Position = UDim2.new(0.1, 0, 0, 145)
rangeLabel.BackgroundTransparency = 1
rangeLabel.Text = "Range: " .. teleportRange .. " studs"
rangeLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
rangeLabel.TextScaled = true
rangeLabel.Font = Enum.Font.Gotham
rangeLabel.Parent = mainFrame

local rangeSlider = Instance.new("TextButton")
rangeSlider.Size = UDim2.new(0.8, 0, 0, 20)
rangeSlider.Position = UDim2.new(0.1, 0, 0, 175)
rangeSlider.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
rangeSlider.Text = ""
rangeSlider.Parent = mainFrame

local rangeFill = Instance.new("Frame")
rangeFill.Size = UDim2.new(0.2, 0, 1, 0)
rangeFill.BackgroundColor3 = Color3.fromRGB(255, 150, 50)
rangeFill.BorderSizePixel = 0
rangeFill.Parent = rangeSlider

toggleBtn.MouseButton1Click:Connect(function()
    enabled = not enabled
    if enabled then
        toggleBtn.BackgroundColor3 = Color3.fromRGB(50, 255, 50)
        toggleBtn.Text = "ON"
    else
        toggleBtn.BackgroundColor3 = Color3.fromRGB(255, 50, 50)
        toggleBtn.Text = "OFF"
    end
end)

local cooldownDragging = false
cooldownSlider.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        cooldownDragging = true
    end
end)

cooldownSlider.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        cooldownDragging = false
    end
end)

uis.InputChanged:Connect(function(input)
    if cooldownDragging and input.UserInputType == Enum.UserInputType.MouseMovement then
        local mousePos = uis:GetMouseLocation().X
        local sliderPos = cooldownSlider.AbsolutePosition.X
        local sliderSize = cooldownSlider.AbsoluteSize.X
        local percent = math.clamp((mousePos - sliderPos) / sliderSize, 0, 1)
        cooldown = math.floor(percent * 50) / 100 + 0.01
        cooldownFill.Size = UDim2.new(percent, 0, 1, 0)
        cooldownLabel.Text = string.format("Cooldown: %.2fs", cooldown)
    end
end)

local rangeDragging = false
rangeSlider.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        rangeDragging = true
    end
end)

rangeSlider.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        rangeDragging = false
    end
end)

uis.InputChanged:Connect(function(input)
    if rangeDragging and input.UserInputType == Enum.UserInputType.MouseMovement then
        local mousePos = uis:GetMouseLocation().X
        local sliderPos = rangeSlider.AbsolutePosition.X
        local sliderSize = rangeSlider.AbsoluteSize.X
        local percent = math.clamp((mousePos - sliderPos) / sliderSize, 0, 1)
        teleportRange = math.floor(percent * 95) + 5
        rangeFill.Size = UDim2.new(percent, 0, 1, 0)
        rangeLabel.Text = string.format("Range: %d studs", teleportRange)
    end
end)

local function getNearestPlayer()
    local nearestPlr = nil
    local shortest = math.huge
    for _, plr in ipairs(players:GetPlayers()) do
        if plr ~= player and plr.Character and plr.Character:FindFirstChild("HumanoidRootPart") then
            local dist = (plr.Character.HumanoidRootPart.Position - hrp.Position).Magnitude
            if dist < shortest then
                shortest = dist
                nearestPlr = plr
            end
        end
    end
    return nearestPlr
end

local function teleportToNearestPlayer()
    if not enabled then return end

    local nearestPlayer = getNearestPlayer()
    if not nearestPlayer or not nearestPlayer.Character then return end

    local targetHRP = nearestPlayer.Character:FindFirstChild("HumanoidRootPart")
    if not targetHRP then return end

    local randomX = math.random(-teleportRange, teleportRange)
    local randomZ = math.random(-teleportRange, teleportRange)
    local targetPos = targetHRP.Position

    hrp.CFrame = CFrame.new(targetPos.X + randomX, targetPos.Y, targetPos.Z + randomZ)
end

task.spawn(function()
    while task.wait(cooldown) do
        if enabled then
            pcall(teleportToNearestPlayer)
        end
    end
end)

player.CharacterAdded:Connect(function(newChar)
    character = newChar
    hrp = character:WaitForChild("HumanoidRootPart")
end)