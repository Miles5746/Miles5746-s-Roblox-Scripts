local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local player = Players.LocalPlayer
local character = player.Character
local humanoid = character:FindFirstChild("Humanoid")
local root = character:FindFirstChild("HumanoidRootPart")
local animator = humanoid:FindFirstChildOfClass("Animator")
local inftoggle = false
local currentSequenceId = 0
local Fluent = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()
local toolReferences = {}
local RunService = game:GetService("RunService")
local stopanim = false
local stopwalk = false
local blacklistedAnimations = {}

print(Players)
print(player)
print(character)
print(humanoid)
print(root)
print(animator)

local blacklistanim = (function()
    local blacklistedAnimations = {}
    local isMonitoring = false
    return function(animationId)
        local cleanId = tostring(animationId):gsub("rbxassetid://", "")
        if not table.find(blacklistedAnimations, cleanId) then
            table.insert(blacklistedAnimations, cleanId)
            print("[BLACKLISTED]", cleanId)
        end
        if not isMonitoring then
            isMonitoring = true
            RunService.Heartbeat:Connect(function()
                local character = player.Character
                if character then
                    local humanoid = character:FindFirstChild("Humanoid")
                    if humanoid then
                        local animator = humanoid:FindFirstChild("Animator")
                        if animator then
                            for _, track in ipairs(animator:GetPlayingAnimationTracks()) do
                                local trackId = tostring(track.Animation.AnimationId):gsub("rbxassetid://", "")
                                
                                if table.find(blacklistedAnimations, trackId) then
                                    track:Stop()
                                    print("[STOPPED]", trackId)
                                end
                            end
                        end
                    end
                end
            end)
        end
    end
end)()

local function stopanimf()
	stopanim = true
	for i,v in next, humanoid:GetPlayingAnimationTracks() do
		v:Stop()
	end
end

local function usemove(toolName)
	if not toolReferences[toolName] then
		warn(toolName .. " tool reference not found!")
		return
	end
	local args = {
		{
			Tool = toolReferences[toolName],
			Goal = "Console Move",
			ToolName = toolName
		}
	}
	local communicate = player.Character:WaitForChild("Communicate", 5)
	if communicate then
		communicate:FireServer(unpack(args))
	else
		warn("Communicate remote not found!")
	end
end

function UnequipAllTools()
	if humanoid then
		humanoid:UnequipTools()
	end
end

function RemoveAllTools()
	local backpack = player:FindFirstChildOfClass("Backpack")
	if backpack then
		for i,v in pairs(backpack:GetDescendants()) do
			if v:IsA('Tool') or v:IsA('HopperBin') then
				v:Destroy()
			end
		end
	end
	if character then
		for i,v in pairs(character:GetDescendants()) do
			if v:IsA('Tool') or v:IsA('HopperBin') then
				v:Destroy()
			end
		end
	end
end


local function notify(title, text, time)
    Fluent:Notify({
        Title = title,
        Content = text,
        Duration = time
    })
end

local function playAudio(soundId, volume, looped)
	local sound = Instance.new("Sound")
	sound.SoundId = "rbxassetid://" .. tostring(soundId)
	sound.Volume = volume or 1
	sound.Looped = looped or false
	sound.Parent = SoundService
	sound:Play()
	return sound
end

local function playAnimation(animationId, speed, looped, customstart)
    if not animator then
        animator = Instance.new("Animator")
        animator.Parent = humanoid
    end
    local animation = Instance.new("Animation")
    animation.AnimationId = "rbxassetid://" .. tostring(animationId)
    local track = animator:LoadAnimation(animation)
    track.Looped = looped or false
    if speed then
        track:Play(0.1, 1, speed)
    else
        track:Play()
    end
    if customstart then
        RunService.Heartbeat:Wait()
        track.TimePosition = customstart
    end
    return track
end

local function playAnimationSequence(animations)
	sequenceTask = task.spawn(function()
		for _, animData in ipairs(animations) do
			if stopanim == false then
				local animId = animData[1] or animData.id
				local speed = animData[2] or animData.speed or 1
				local duration = animData[3] or animData.duration

				local track = playAnimation(animId, speed, false)
				if not track then return end

				if duration then
					task.wait(duration)
					track:Stop()
				else
					track.Stopped:Wait()
				end
			end
		end
	end)
end



local function walkForward(duration, speed)
	local startTime = tick()
	local connection
	connection = RunService.Heartbeat:Connect(function(dt)
		if tick() - startTime >= duration or stopwalk == true then
			connection:Disconnect()
			return
		end
		local forward = root.CFrame.LookVector
		root.CFrame = root.CFrame + forward * speed * dt
	end)
end

local function backupAllTools(player)
	if not player then
		player = game:GetService("Players").LocalPlayer
	end
	if not player then return end

	local backpack = player:FindFirstChildOfClass("Backpack") or player:WaitForChild("Backpack")
	if not backpack then
		return
	end

	local fbp = player:FindFirstChild("fbp")
	if not fbp then
		fbp = Instance.new("Folder")
		fbp.Name = "fbp"
		fbp.Parent = player
	end

	-- Store ALL tool references BEFORE removing tools
	for _, tool in ipairs(backpack:GetChildren()) do
		if tool:IsA("Tool") or tool:IsA("HopperBin") then
			toolReferences[tool.Name] = tool
			print("Captured reference for: " .. tool.Name)
			
			local clone = tool:Clone()
			clone.Parent = fbp
		end
	end
end

local function restoreAllTools(player)
    if not player then
		player = game:GetService("Players").LocalPlayer
	end
    local backpack = player:FindFirstChild("Backpack")
    local fbp = player:FindFirstChild("fbp")
	if not fbp then return end
    for _, tool in ipairs(fbp:GetChildren()) do
        if tool:IsA("Tool") or tool:IsA("HopperBin") then
			tool.Parent = backpack
		end
    end
end


local function hideHotbarSelector(tool)
	local success, err = pcall(function()
		local gui = player.PlayerGui.Hotbar.Backpack.Hotbar[tool].Base.Overlay
		gui.Visible = false
	end)
	if not success then
		warn("Could not hide hotbar selector: " .. tostring(err))
	end
end

local function toolactivated(name)
	if name == "Infinity" then
		inftoggle = not inftoggle
		if inftoggle then
			playAudio(13064703752, 1, false)
            notify("Infinity", "Infinity has activated.", 2)
		else
			playAudio(13064703579, 1, false)
            notify("Infinity", "Infinity has deactivated.", 2)
		end

		hideHotbarSelector("1")

		local humanoid1 = player.Character and player.Character:FindFirstChildWhichIsA("Humanoid")
		if humanoid1 then
			humanoid1.Died:Connect(function()
				inftoggle = false
			end)
		end
		task.spawn(function()
			while inftoggle do
				RunService.Heartbeat:Wait()
				if root then
					local vel = root.Velocity
					root.Velocity = vel * 10000 + Vector3.new(0, 10000, 0)
					RunService.RenderStepped:Wait()
					if root then
						root.Velocity = vel
					end
					RunService.Stepped:Wait()
					if root then
						root.Velocity = vel + Vector3.new(0, 0.1, 0)
					end
				end
			end
		end)
	end
    if name == "Speed flick" then
		hideHotbarSelector("2")
		stopanimf()
		stopanim = false
		local startTime = tick()
		local HIT_WINDOW = 2.2000000178813934
		local alreadyHit = {}
		local TweenService = game:GetService("TweenService")

		local function onPlayerHit(hitHumanoid, hitCharacter)
			stopanimf()
			stopwalk = true
			print("[DEBUG] HIT:", hitCharacter.Name)
			task.spawn(function()
				local targetRoot = hitCharacter:FindFirstChild("HumanoidRootPart")
				if targetRoot then
					local lookDirection = targetRoot.CFrame.LookVector
					local behindPosition50 = targetRoot.Position - (lookDirection * 50)
					root.CFrame = CFrame.new(behindPosition50, targetRoot.Position)
					usemove("Normal Punch")
					local behindPosition1 = targetRoot.Position - (lookDirection * 1)
					local targetCFrame = CFrame.new(behindPosition1, targetRoot.Position)
					local tweenInfo = TweenInfo.new(0.4, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut)
					local tween = TweenService:Create(root, tweenInfo, {CFrame = targetCFrame})
					tween:Play()
					wait(0.1)
					playAnimation(12832505612, 0.5, false, 1.6)
				end
			end)
		end

		local function setupHitDetection()
			for _, part in ipairs(character:GetDescendants()) do
				if part:IsA("BasePart") then
					part.Touched:Connect(function(hit)
						if (tick() - startTime) > HIT_WINDOW then return end
						
						local hitModel = hit:FindFirstAncestorOfClass("Model")
						
						if hitModel and hitModel:IsDescendantOf(game.Workspace.Live) then
							local hitHumanoid = hitModel:FindFirstChild("Humanoid")
							
							if hitHumanoid and not alreadyHit[hitModel] then
								alreadyHit[hitModel] = true
								onPlayerHit(hitHumanoid, hitModel)
							end
						end
					end)
				end
			end
		end

		setupHitDetection()

		playAnimationSequence({
			{132259592388175},
			{95575238948327},
			{95575238948327},
			{95575238948327}
		})

		walkForward(HIT_WINDOW, 80)

		task.wait(HIT_WINDOW)
		stopanim = false
		stopwalk = false
		alreadyHit = {}
	end
end

local function addtools(name)
	local backpack = player:WaitForChild("Backpack")
	local tool = Instance.new("Tool")
	tool.Name = name or "NewTool"
	tool.RequiresHandle = false
	tool.CanBeDropped = false
	tool.Parent = backpack

	tool.Equipped:Connect(function()
		wait(0.1)
		toolactivated(name)
	end)
	tool.Unequipped:Connect(function()
		wait(0.1)
		if not character:FindFirstChildOfClass("Tool") then
			toolactivated(name)
		end
	end)

	return tool
end

local function loadscript()
    local fakebackpack = Instance.new("Folder")
    fakebackpack.Parent = player
    fakebackpack.Name = "fbp"

    UnequipAllTools()
    backupAllTools(player)
    RemoveAllTools()
    addtools("Infinity")
    addtools("Speed flick")
	addtools("Ghost")
    restoreAllTools(player)

	blacklistanim(10468665991)

    notify("Piliex Script loaded!", "Made with ♡ by Per0n2001.", 5)
end


--==================================================================================================================================================
--Key system
--==================================================================================================================================================
local Keysystem = Fluent:CreateWindow({
    Title = "Piliex Key system",
    SubTitle = "Made by Per0n2001",
    TabWidth = 160,
    Size = UDim2.fromOffset(580, 460),
    Acrylic = true,
    Theme = "Dark",
    MinimizeKey = Enum.KeyCode.LeftControl
})
local tabs = {
    Redeem = Keysystem:AddTab({ Title = "Redeem", Icon = ""})
}
local Options = Fluent.Options
do
    tabs.Redeem:AddParagraph({
        Title = "Instructions",
        Content = "Go get a key at work.ink and come back to redeem it.\nDon't worry! They don't expire."
    })

    tabs.Redeem:AddButton({
        Title = "Get key",
        Description = "Copys key link",
        Callback = function()
            setclipboard("https://work.ink/27jN/0deh5d90")
            Fluent:Notify({
                Title = "Key system",
                Content = "Key link copied to clipboard",
                Duration = 3
            })
        end
    })

    tabs.Redeem:AddInput("Input", {
        Title = "Enter key",
        Default = "",
        Placeholder = "Enter key here",
        Numeric = false,
        Finished = true,
        Callback = function(Value)
            if Value == "temp3_pstbn" then
                loadscript()
				Keysystem:Destroy()
            else
                Fluent:Notify({
                    Title = "Key Invalid!",
                    Content = "Please try again.",
                    Duration = 3
                })
            end
        end
    })
end