local Fluent = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()
local SaveManager = loadstring(game:HttpGet("https://raw.githubusercontent.com/dawid-scripts/Fluent/master/Addons/SaveManager.lua"))()
local InterfaceManager = loadstring(game:HttpGet("https://raw.githubusercontent.com/dawid-scripts/Fluent/master/Addons/InterfaceManager.lua"))()
local Players = game:GetService("Players")
local player = Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoidRootPart = character:WaitForChild("HumanoidRootPart")
local delay = 1
local refresh = 0

-- Box unequip blocker setup
local blockUnequip = false

local mt = getrawmetatable(game)
local oldNamecall = mt.__namecall
setreadonly(mt, false)

mt.__namecall = newcclosure(function(self, ...)
    local method = getnamecallmethod()
    local args = {...}
    
    if method == "FireServer" and blockUnequip then
        -- Check if it's the BoxUpdated remote
        if self.Name == "BoxUpdated" then
            -- Check if the first argument is "Unequip"
            if args[1] == "Unequip" then
                warn("Blocked BoxUpdated 'Unequip' call")
                return -- Block the remote from firing
            end
        end
    end
    
    return oldNamecall(self, ...)
end)

setreadonly(mt, true)

-- Function to toggle blocking on/off
function boxunequip(enabled)
    blockUnequip = enabled
    if enabled then
        print("Box unequip blocker enabled - You will stay in boxing mode")
    else
        print("Box unequip blocker disabled - You can unequip normally")
    end
end

-- Fix camera function
function fixcam()
    workspace.CurrentCamera:Destroy()
    task.wait(0.1)
    repeat task.wait() until player.Character ~= nil
    workspace.CurrentCamera.CameraSubject = player.Character:FindFirstChildWhichIsA('Humanoid')
    workspace.CurrentCamera.CameraType = "Custom"
    player.CameraMinZoomDistance = 0.5
    player.CameraMaxZoomDistance = 400
    player.CameraMode = "Classic"
    player.Character.Head.Anchored = false
end

-- Function to check if any monster is near an item
function isMonsterNearby(itemPosition)
    local monsters = workspace:FindFirstChild("Monsters")
    if not monsters then 
        return false, nil 
    end
    
    -- List of monster names to check
    local monsterNames = {"Blue", "Green", "Cyan", "Bird"}
    
    -- Check distance to each monster
    for _, monsterName in pairs(monsterNames) do
        local monster = monsters:FindFirstChild(monsterName)
        if monster then
            local hrp = monster:FindFirstChild("HumanoidRootPart")
            if hrp then
                local distance = (hrp.Position - itemPosition).Magnitude
                if distance <= 5 then
                    return true, monsterName
                end
            end
        end
    end
    
    return false, nil
end

-- Invisible function setup
local invisRunning = false
local IsInvis = false
local IsRunning = true
local InvisibleCharacter
local invisFix
local invisDied
local Character
local CF

function makeInvisible(enabled)
    if enabled then
        if invisRunning then return end
        invisRunning = true
        
        Character = player.Character
        if not Character then return end
        
        -- Step 1 & 2: Save the player's current position
        local savedPosition = Character.HumanoidRootPart.CFrame
        
        -- Step 3: Teleport the player to the safe coordinates
        Character.HumanoidRootPart.CFrame = CFrame.new(-79, 136, -129)
        task.wait(0.3)
        
        -- Step 4: Create the invisible clone
        Character.Archivable = true
        IsInvis = false
        IsRunning = true
        InvisibleCharacter = Character:Clone()
        InvisibleCharacter.Parent = game:GetService("Lighting")
        local Void = workspace.FallenPartsDestroyHeight
        InvisibleCharacter.Name = ""
        
        invisFix = game:GetService("RunService").Stepped:Connect(function()
            pcall(function()
                local IsInteger
                if tostring(Void):find('-') then
                    IsInteger = true
                else
                    IsInteger = false
                end
                if player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
                    local Pos = player.Character.HumanoidRootPart.Position
                    local Y = Pos.Y
                    if IsInteger == true then
                        if Y <= Void then
                            makeInvisible(false)
                        end
                    elseif IsInteger == false then
                        if Y >= Void then
                            makeInvisible(false)
                        end
                    end
                end
            end)
        end)
        
        for i,v in pairs(InvisibleCharacter:GetDescendants()) do
            if v:IsA("BasePart") then
                if v.Name == "HumanoidRootPart" then
                    v.Transparency = 1
                else
                    v.Transparency = 0.5
                end
            end
        end
        
        invisDied = InvisibleCharacter:FindFirstChildOfClass('Humanoid').Died:Connect(function()
            makeInvisible(false)
        end)
        
        IsInvis = true
        CF = workspace.CurrentCamera.CFrame
        
        -- Move real character to the void
        Character:MoveTo(Vector3.new(0, math.pi * 1000000, 0))
        workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
        task.wait(0.2)
        workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
        Character.Parent = game:GetService("Lighting")
        
        -- Step 5: Teleport the clone to the player's saved position
        InvisibleCharacter.Parent = workspace
        InvisibleCharacter.HumanoidRootPart.CFrame = savedPosition
        player.Character = InvisibleCharacter
        
        fixcam()
        player.Character.Animate.Disabled = true
        player.Character.Animate.Disabled = false
        
        print("Invisible mode enabled")
    else
        -- Turn visible
        if not IsInvis then return end
        
        if invisFix then invisFix:Disconnect() end
        if invisDied then invisDied:Disconnect() end
        
        -- Step 7: Save the clone's current position
        local clonePosition = player.Character.HumanoidRootPart.CFrame
        
        -- Step 8: Delete the clone (happens automatically when we switch characters)
        -- Step 9: Spawn back the normal player
        if InvisibleCharacter then InvisibleCharacter:Destroy() end
        player.Character = Character
        Character.Parent = workspace
        IsInvis = false
        player.Character.Animate.Disabled = true
        player.Character.Animate.Disabled = false
        
        -- Step 10: Teleport the player to the clone's saved position
        task.wait(0.1)
        Character.HumanoidRootPart.CFrame = clonePosition
        
        -- Update the humanoidRootPart reference
        humanoidRootPart = Character:WaitForChild("HumanoidRootPart")
        
        invisDied = Character:FindFirstChildOfClass('Humanoid').Died:Connect(function()
            makeInvisible(false)
            if invisDied then invisDied:Disconnect() end
        end)
        
        invisRunning = false
        
        print("Invisible mode disabled")
    end
end

function lookys()
    Fluent:Notify({
        Title = "Collecting Lookies...",
        Content = "This is still work in progress. You may experience lots of bugs.",
        SubContent = "",
        Duration = 5
    })

    for _, instance in ipairs(workspace.ignore:GetDescendants()) do
        if instance:IsA("Model") and instance.Name == "Looky" then
            if not instance.PrimaryPart then
                warn("Looky doesn't have primary part")
                continue
            end
            humanoidRootPart.CFrame = instance.PrimaryPart.CFrame + Vector3.new(0, 5, 0)
            task.wait(delay)
            humanoidRootPart.CFrame = CFrame.new(52, 138, -7)
            task.wait(delay)
        end
    end

    Fluent:Notify({
        Title = "Lookies collected.",
        Content = "Run again if needed.",
        SubContent = "",
        Duration = 5
    })
end

function item(targetName)
    refresh = 0

    Fluent:Notify({
        Title = "Collecting " .. targetName .. "s...",
        Content = "You might want to try turning on box spoof in Fun, it makes this a whole lot less riskier.",
        SubContent = "",
        Duration = 5
    })

    local skipped = 0
    local collected = 0

    for _, instance in ipairs(workspace:GetDescendants()) do
        if instance:IsA("Model") and instance.Name == targetName then
            -- Make sure the model has a PrimaryPart
            if not instance.PrimaryPart then
                warn("Model '"..targetName.."' has no PrimaryPart:", instance:GetFullName())
                continue
            end
            
            -- Check if any monster is nearby
            local nearMonster, monsterName = isMonsterNearby(instance.PrimaryPart.Position)
            if nearMonster == true then
                warn("Skipping " .. targetName .. " - " .. tostring(monsterName) .. " is nearby")
                skipped = skipped + 1
                continue
            end
            
            -- Keep character upright while teleporting
            local targetCFrame = instance.PrimaryPart.CFrame + Vector3.new(0, 5, 0)
            humanoidRootPart.CFrame = CFrame.new(targetCFrame.Position) * CFrame.Angles(0, 0, 0)
            collected = collected + 1
            refresh = refresh + 1
            task.wait(delay)
            if refresh == 9 then
                humanoidRootPart.CFrame = CFrame.new(52, 138, -7)
                refresh = 0
                task.wait(delay)
            end
        end
    end

    humanoidRootPart.CFrame = CFrame.new(52, 138, -7)

    Fluent:Notify({
        Title = targetName .. " Collected.",
        Content = "Collected: " .. collected .. " | Skipped: " .. skipped,
        SubContent = "",
        Duration = 5
    })
end

local Window = Fluent:CreateWindow({
    Title = "PieCake",
    SubTitle = "Rainbow friends chapter 2 hacks",
    TabWidth = 160,
    Size = UDim2.fromOffset(580, 460),
    Acrylic = true, -- The blur may be detectable, setting this to false disables blur entirely
    Theme = "Dark",
    MinimizeKey = Enum.KeyCode.LeftControl -- Used when theres no MinimizeKeybind
})

local Tabs = {
    Main = Window:AddTab({ Title = "Collect", Icon = "briefcase" }),
    Fun = Window:AddTab({ Title = "Fun", Icon = "popcorn"}),
    Minecart = Window:AddTab({ Title = "Orange coster", Icon = "mountain"}),
    Settings = Window:AddTab({ Title = "Settings", Icon = "settings" })
}

local Options = Fluent.Options

do
    Fluent:Notify({
        Title = "Script loaded",
        Content = "PieCake script loaded.",
        SubContent = "Your welcome that it is keyless",
        Duration = 5
    })
    
    Tabs.Main:AddParagraph({
        Title = "Usage",
        Content = "Click on the appropriate button depending on what you have to find."
    })

    local Slider = Tabs.Main:AddSlider("Teleport delay", {
        Title = "Teleport delay",
        Description = "The amount of seconds the script waits between collecting each item",
        Default = 1,
        Min = 0.1,
        Max = 3,
        Rounding = 1,
        Callback = function(Value)
            delay = Value
        end
    })
    
    Tabs.Main:AddButton({
        Title = "Get Light Bulbs",
        Description = "Collects all the light bulbs around the map",
        Callback = function()
            item("LightBulb")
        end
    })
    
    Tabs.Main:AddButton({
        Title = "Get Gas Canisters",
        Description = "Collects all the gas canisters around the map",
        Callback = function()
            item("GasCanister")
        end
    })
    
    Tabs.Main:AddButton({
        Title = "Get Lookies",
        Description = "Collects all the Lookies around the map",
        Callback = function()
            lookys()
        end
    })
    
    Tabs.Main:AddButton({
        Title = "Get Sugar",
        Description = "Collects all the sugar around the map",
        Callback = function()
            item("CakeMix")
        end
    })

    Tabs.Minecart:AddParagraph({
        Title = "Usage",
        Content = "Orange minecart related features"
    })

    Tabs.Minecart:AddButton({
        Title = "Auto complete coster",
        Description = "Automatically completes the roller coaster",
        Callback = function()
            Fluent:Notify({
                Title = "Feature not implemented",
                Content = "This feature needs to be coded still.",
                Duration = 3
            })
        end
    })

    Tabs.Minecart:AddButton({
        Title = "Teleport to end",
        Description = "Teleports to the end of the cyan chase",
        Callback = function()
            humanoidRootPart.CFrame = CFrame.new(1263, -171, 529)
            Fluent:Notify({
                Title = "Teleported",
                Content = "You have arrived.",
                Duration = 3
            })
        end
    })

    Tabs.Fun:AddParagraph({
        Title = "Usage",
        Content = "Some funny stuff you can do"
    })

    Tabs.Fun:AddButton({
        Title = "Box spoof",
        Description = "Pretends to box, making you invincible to Blue, Yellow, and Cyan.\n(Although if you move infront of Cyan in this form she can still get you.)",
        Callback = function()
            local args = {
                "Equip"
            }
            game:GetService("ReplicatedStorage"):WaitForChild("communication"):WaitForChild("boxes"):WaitForChild("cl"):WaitForChild("BoxUpdated"):FireServer(unpack(args))
            boxunequip(true) -- Start blocking unequip remote
            Fluent:Notify({
                Title = "Box spoof activated",
                Content = "You will now be invincible to Blue, Yellow, and Cyan",
                Duration = 3
            })
        end
    })

    Tabs.Fun:AddButton({
        Title = "Stop box spoof",
        Description = "Stops pretending to box",
        Callback = function()
            boxunequip(false) -- Stop blocking unequip remote
            local args = {
                "Unequip"
            }
            game:GetService("ReplicatedStorage"):WaitForChild("communication"):WaitForChild("boxes"):WaitForChild("cl"):WaitForChild("BoxUpdated"):FireServer(unpack(args))
            Fluent:Notify({
                Title = "Box spoof deactivated",
                Content = "Blue, Yellow, and Cyan can kill you again.",
                Duration = 3
            })
        end
    })

    Tabs.Fun:AddButton({
        Title = "Invisible",
        Description = "Starts being invisible.\nYou can't pick up any items during invisibility, but monsters can't see or attack you.",
        Callback = function()
            makeInvisible(true)
            Fluent:Notify({
                Title = "Invisible mode activated",
                Content = "Monsters can no longer see or attack you",
                Duration = 3
            })
        end
    })

    Tabs.Fun:AddButton({
        Title = "Uninvisible",
        Description = "Stops being invisible",
        Callback = function()
            makeInvisible(false)
            Fluent:Notify({
                Title = "Invisible mode deactivated",
                Content = "You are now visible and can pick up items again",
                Duration = 3
            })
        end
    })

    Tabs.Fun:AddButton({
        Title = "Spectator mode",
        Description = "Respawns you, in a spectator mode, where no monster can even see you. Can be used while dead.\nNote: This also means you can't pick up any items.",
        Callback = function()
            character:WaitForChild("Humanoid").Health = 0
            player.PlayerGui.PermanentGUI.YouDied.Visible = false
            task.wait(6)
            workspace.CurrentCamera:Destroy()
            task.wait(0.1)
            repeat task.wait() until player.Character ~= nil
            character = player.Character
            humanoidRootPart = character:WaitForChild("HumanoidRootPart")
            workspace.CurrentCamera.CameraSubject = character:FindFirstChildWhichIsA('Humanoid')
            workspace.CurrentCamera.CameraType = "Custom"
            player.CameraMinZoomDistance = 0.5
            player.CameraMaxZoomDistance = 400
            player.CameraMode = "Classic"
            character.Head.Anchored = false
            player.PlayerGui.PermanentGUI.DeathFrame.Visible = false
            player.PlayerGui.PermanentGUI.Spectate.Visible = false
            humanoidRootPart.CFrame = CFrame.new(52, 138, -7)
        end
    })

    Tabs.Fun:AddButton({
        Title = "Fix camera",
        Description = "Fixes your camera if it gets stuck or broken",
        Callback = function()
            fixcam()
            Fluent:Notify({
                Title = "Camera fixed",
                Content = "Your camera has been reset",
                Duration = 2
            })
        end
    })
end