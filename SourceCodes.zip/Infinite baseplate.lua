-- Resources: [Honored Emote ID: 15503060232] [Infinite void position: 1073 406 22984]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextChatService = game:GetService("TextChatService")
local RunService = game:GetService("RunService")

local localPlayer = Players.LocalPlayer
local char = localPlayer.Character or localPlayer.CharacterAdded:Wait()
local hrp = char:WaitForChild("HumanoidRootPart")
local humanoid = char:WaitForChild("Humanoid")
local animator = humanoid:WaitForChild("Animator")

local TARGET_ANIMATION_ID = "rbxassetid://15503060232"
local isLegacyChat = TextChatService == nil or TextChatService.ChatVersion == Enum.ChatVersion.LegacyChatService

local function proceed(nearest)
    humanoid:UnequipTools()
    local VirtualInputManager = game:GetService("VirtualInputManager")
    VirtualInputManager:SendKeyEvent(true, Enum.KeyCode.F, false, game)
    task.wait(0.05)
    VirtualInputManager:SendKeyEvent(false, Enum.KeyCode.F, false, game)
    if nearest and nearest.Character and nearest.Character:FindFirstChild("HumanoidRootPart") then
        local myChar = localPlayer.Character or localPlayer.CharacterAdded:Wait()
        local myHRP = myChar:WaitForChild("HumanoidRootPart")
        local targetHRP = nearest.Character.HumanoidRootPart

        local behindOffset = targetHRP.CFrame.LookVector * -2
        myHRP.CFrame = CFrame.new(targetHRP.Position + behindOffset, targetHRP.Position)
        
        task.wait(0.2)
        
        local backpack = localPlayer:WaitForChild("Backpack")
        local tools = backpack:GetChildren()
        local toolList = {}
        for _, item in ipairs(tools) do
            if item:IsA("Tool") then
                table.insert(toolList, item)
            end
        end
        if toolList[4] then
            humanoid:EquipTool(toolList[4])
        else
            warn("No fourth tool found in backpack")
        end
        
        task.wait(2)
        myHRP.CFrame = CFrame.new(1073, 450, 22984)
        humanoid:UnequipTools()
    end
end

local function chatMessage(str)
    str = tostring(str)
    if not isLegacyChat and TextChatService:FindFirstChild("TextChannels") and TextChatService.TextChannels:FindFirstChild("RBXGeneral") then
        TextChatService.TextChannels.RBXGeneral:SendAsync(str)
    elseif ReplicatedStorage:FindFirstChild("DefaultChatSystemChatEvents") then
        ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(str, "All")
    else
        warn("No valid chat system found!")
    end
end

local function getNearestPlayer()
    local nearestPlr = nil
    local shortest = math.huge
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= localPlayer and plr.Character and plr.Character:FindFirstChild("HumanoidRootPart") then
            local dist = (plr.Character.HumanoidRootPart.Position - hrp.Position).Magnitude
            if dist < shortest then
                shortest = dist
                nearestPlr = plr
            end
        end
    end
    return nearestPlr
end

local function start()
    task.wait(1)
    chatMessage("Through the universe of time, from civilizations to demons, there is one power feared by all.")
    task.wait(3)
    local target = getNearestPlayer()
    chatMessage("By all, I mean you.. " .. (target and target.Name or "nobody") .. ".")
    task.wait(4)
    chatMessage("...")
    task.wait(2)
    chatMessage("Domain expansion...")
    task.wait(2.5)
    chatMessage("=;I N F I N I T E   V O I D;=")
    task.wait(0.8)
    proceed(target)
end

local lastPlaying = {}
local hasTriggered = false

RunService.RenderStepped:Connect(function()
    local tracks = animator:GetPlayingAnimationTracks()
    local current = {}
    
    for _, track in ipairs(tracks) do
        local anim = track.Animation
        if anim and anim.AnimationId then
            current[anim.AnimationId] = true
        end
    end
    
    for id in pairs(current) do
        if not lastPlaying[id] and id == TARGET_ANIMATION_ID and not hasTriggered then
            hasTriggered = true
            task.wait(0.1)
            start()
        end
    end
    
    if not current[TARGET_ANIMATION_ID] then
        hasTriggered = false
    end
    
    lastPlaying = current
end)
