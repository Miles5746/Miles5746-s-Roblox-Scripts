--== Services ==--

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local SoundService = game:GetService("SoundService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

--== Player ==--

local player = Players.LocalPlayer
local backpack = player:FindFirstChildOfClass("Backpack") or player:WaitForChild("Backpack")
local char = player.Character or player.CharacterAdded:Wait()
local hum = char:WaitForChild("Humanoid")
local root = char:WaitForChild("HumanoidRootPart")
local animator = hum:FindFirstChildOfClass("Animator")
local camera = Workspace.CurrentCamera

--== Tables ==--

local AnimateTable = {
    Intro = "rbxassetid://17325160621",
    Ravage1 = "rbxassetid://16945573694",
    Ravage2 = "rbxassetid://16945550029",
    SwiftSweep = "rbxassetid://16944265635",
    CollaRuin = "rbxassetid://17325254223",
    SpiralStorm1 = "rbxassetid://78521642007560",
    SpiralStorm2 = "rbxassetid://81827172076105",
    Ult = "rbxassetid://17140902079",
    StoicBomb = "rbxassetid://17141153099",
    FiveSeasons = "rbxassetid://18462892217",
    UnlimitedFlexWorks = "rbxassetid://77727115892579"
}

local SoundTable = {
    Intro = "rbxassetid://17325174223",
    Ravage1 = "rbxassetid://16945495411",
    Ravage2 = "rbxassetid://16945593216",
    Ravage3 = "rbxassetid://16945723339",
    SwiftSweep = "rbxassetid://16944654157",
    CollaRuin1 = "rbxassetid://74376324560435",
    CollaRuin2 = "rbxassetid://72000489811842",
    SpiralStorm1 = "rbxassetid://72864971245980",
    SpiralStorm2 = "rbxassetid://89085076665315",
    UltSongStart = "rbxassetid://17150550559",
    UltSongLoop = "rbxassetid://17150550093",
    UltVoiceline = "rbxassetid://17150550302",
    StoicBombCharge = "rbxassetid://17141392976",
    StoicBombExplode = "rbxassetid://17141392854",
    StoicBombVoiceline = "rbxassetid://17141392676",
    StartSong202020 = "rbxassetid://17356346310",
    RunSfx202020 = "rbxassetid://17429233290",
    CutsceneMusic202020 = "rbxassetid://17363383992",
    CamSfx202020 = "rbxassetid://17419337758",
    GuiSfx202020 = "rbxassetid://17420207822",
    FiveSeasonsTheme = "rbxassetid://18460952794",
    FiveSeasonsFirstPart = "rbxassetid://18460863844",
    FiveSeasonsVoiceline1 = "rbxassetid://18460893321",
    FiveSeasonsVoiceline2 = "rbxassetid://18461821277",
    FiveSeasonsHands = "rbxassetid://18462018744",
    FiveSeasonsImpact = "rbxassetid://18462312002",
    FiveSeasonsExplosion = "rbxassetid://18462330981",
    FlexWorksSFX = "rbxassetid://99126314241685",
    FlexWorksVoiceline = "rbxassetid://128136381213631",
    FlexWorksMusic = "rbxassetid://95410275491981",
    FlexWorksHit = "rbxassetid://118747531933793"
}
local MoveTable = {
    Ravage = "1"
}

--== Other ==--

local stopanim = false
local stopwalk = false
local currentSequenceId = 0
local coms = char:WaitForChild("Communicate")
local fbp = Instance.new("Folder")
fbp.Parent = player
fbp.Name = "fbp"
fbp = player:FindFirstChild("fbp")

local blacklistedAnimations = {}
local toolReferences = {}
local sequenceTask = nil

local Fluent = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()

--== Classes ==--

local Animations = {}
local Sounds = {}
local Tools = {}
local Movesets = {}
local Ultimates = {}

Animations.__index = Animations
Tools.__index = Tools
Movesets.__index = Movesets
Ultimates.__index = Ultimates
Sounds.__index = Sounds

--== Functions ==--
function CreateDebugUI()
    -- Create ScreenGui
    local screenGui = Instance.new("ScreenGui")
    screenGui.Name = "DebugUI"
    screenGui.ResetOnSpawn = false
    screenGui.Parent = player.PlayerGui
    
    -- Create Frame
    local frame = Instance.new("Frame")
    frame.Name = "MainFrame"
    frame.Size = UDim2.new(0, 400, 0, 300)
    frame.Position = UDim2.new(0.5, -200, 0.5, -150)
    frame.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
    frame.BorderSizePixel = 0
    frame.Active = true
    frame.Draggable = true
    frame.Parent = screenGui
    
    -- Add UICorner to frame
    local frameCorner = Instance.new("UICorner")
    frameCorner.CornerRadius = UDim.new(0, 10)
    frameCorner.Parent = frame
    
    -- Create Title Label
    local titleLabel = Instance.new("TextLabel")
    titleLabel.Name = "Title"
    titleLabel.Size = UDim2.new(1, 0, 0, 40)
    titleLabel.Position = UDim2.new(0, 0, 0, 0)
    titleLabel.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
    titleLabel.BorderSizePixel = 0
    titleLabel.Text = "Debug Console"
    titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    titleLabel.TextSize = 18
    titleLabel.Font = Enum.Font.GothamBold
    titleLabel.Parent = frame
    
    -- Add UICorner to title
    local titleCorner = Instance.new("UICorner")
    titleCorner.CornerRadius = UDim.new(0, 10)
    titleCorner.Parent = titleLabel
    
    -- Create TextBox (larger for code)
    local textBox = Instance.new("TextBox")
    textBox.Name = "CodeInput"
    textBox.Size = UDim2.new(0.9, 0, 0, 180)
    textBox.Position = UDim2.new(0.05, 0, 0.18, 0)
    textBox.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
    textBox.BorderSizePixel = 0
    textBox.PlaceholderText = "Enter Lua code here..."
    textBox.Text = ""
    textBox.TextColor3 = Color3.fromRGB(255, 255, 255)
    textBox.PlaceholderColor3 = Color3.fromRGB(150, 150, 150)
    textBox.TextSize = 14
    textBox.Font = Enum.Font.Code
    textBox.ClearTextOnFocus = false
    textBox.MultiLine = true
    textBox.TextXAlignment = Enum.TextXAlignment.Left
    textBox.TextYAlignment = Enum.TextYAlignment.Top
    textBox.TextWrapped = true
    textBox.Parent = frame
    
    -- Add UICorner to textbox
    local textBoxCorner = Instance.new("UICorner")
    textBoxCorner.CornerRadius = UDim.new(0, 8)
    textBoxCorner.Parent = textBox
    
    -- Create Execute Button
    local executeButton = Instance.new("TextButton")
    executeButton.Name = "ExecuteButton"
    executeButton.Size = UDim2.new(0.43, 0, 0, 35)
    executeButton.Position = UDim2.new(0.05, 0, 0.85, 0)
    executeButton.BackgroundColor3 = Color3.fromRGB(0, 170, 0)
    executeButton.BorderSizePixel = 0
    executeButton.Text = "Execute"
    executeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    executeButton.TextSize = 16
    executeButton.Font = Enum.Font.GothamBold
    executeButton.Parent = frame
    
    -- Add UICorner to execute button
    local executeCorner = Instance.new("UICorner")
    executeCorner.CornerRadius = UDim.new(0, 8)
    executeCorner.Parent = executeButton
    
    -- Create Clear Button
    local clearButton = Instance.new("TextButton")
    clearButton.Name = "ClearButton"
    clearButton.Size = UDim2.new(0.43, 0, 0, 35)
    clearButton.Position = UDim2.new(0.52, 0, 0.85, 0)
    clearButton.BackgroundColor3 = Color3.fromRGB(170, 0, 0)
    clearButton.BorderSizePixel = 0
    clearButton.Text = "Clear"
    clearButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    clearButton.TextSize = 16
    clearButton.Font = Enum.Font.GothamBold
    clearButton.Parent = frame
    
    -- Add UICorner to clear button
    local clearCorner = Instance.new("UICorner")
    clearCorner.CornerRadius = UDim.new(0, 8)
    clearCorner.Parent = clearButton
    
    -- Button hover effects
    executeButton.MouseEnter:Connect(function()
        executeButton.BackgroundColor3 = Color3.fromRGB(0, 150, 0)
    end)
    
    executeButton.MouseLeave:Connect(function()
        executeButton.BackgroundColor3 = Color3.fromRGB(0, 170, 0)
    end)
    
    clearButton.MouseEnter:Connect(function()
        clearButton.BackgroundColor3 = Color3.fromRGB(150, 0, 0)
    end)
    
    clearButton.MouseLeave:Connect(function()
        clearButton.BackgroundColor3 = Color3.fromRGB(170, 0, 0)
    end)
    
    -- Execute button click event
    executeButton.MouseButton1Click:Connect(function()
        local code = textBox.Text
        if code and code ~= "" then
            -- Create environment with access to all your functions and variables
            local env = {
                -- Services
                game = game,
                workspace = workspace,
                Workspace = Workspace,
                Players = Players,
                RunService = RunService,
                TweenService = TweenService,
                SoundService = SoundService,
                UserInputService = UserInputService,
                ReplicatedStorage = ReplicatedStorage,
                
                -- Player variables
                player = player,
                backpack = backpack,
                char = char,
                hum = hum,
                root = root,
                animator = animator,
                camera = camera,
                
                -- Tables
                AnimateTable = AnimateTable,
                SoundTable = SoundTable,
                MoveTable = MoveTable,
                
                -- Functions/Classes
                Animations = Animations,
                Tools = Tools,
                Movesets = Movesets,
                Ultimates = Ultimates,
                Sounds = Sounds,
                RemoteEvent = RemoteEvent,
                getNearestCharacter = getNearestCharacter,
                BlackList = BlackList,
                
                -- Standard Lua functions
                print = print,
                warn = warn,
                wait = wait,
                task = task,
                tick = tick,
                time = time,
                tonumber = tonumber,
                tostring = tostring,
                type = type,
                pairs = pairs,
                ipairs = ipairs,
                next = next,
                pcall = pcall,
                xpcall = xpcall,
                select = select,
                unpack = unpack,
                table = table,
                math = math,
                string = string,
                coroutine = coroutine,
                
                -- Instance creation
                Instance = Instance,
                Vector3 = Vector3,
                Vector2 = Vector2,
                CFrame = CFrame,
                UDim2 = UDim2,
                UDim = UDim,
                Color3 = Color3,
                Enum = Enum
            }
            
            -- Set the metatable to allow access to _G and other globals
            setmetatable(env, {__index = getfenv()})
            
            local success, result = pcall(function()
                local func, err = loadstring(code)
                if not func then
                    error("Syntax Error: " .. tostring(err))
                end
                setfenv(func, env)
                return func()
            end)
            
            if success then
                if result ~= nil then
                    print("[Debug] Executed successfully. Result:", result)
                else
                    print("[Debug] Executed successfully.")
                end
            else
                warn("[Debug] Error:", result)
            end
        end
    end)
    
    -- Clear button click event
    clearButton.MouseButton1Click:Connect(function()
        textBox.Text = ""
    end)
    
    print("[Debug] Debug UI created! You can now enter code.")
    return screenGui, frame, textBox
end

local function getNearestCharacter()
    local closestDistance = math.huge
    local closestRoot = nil
    for _, model in ipairs(workspace.Live:GetChildren()) do
        if model:IsA("Model") and model ~= char then
            local otherhumanoid = model:FindFirstChildOfClass("Humanoid")
            local otherhrp = model:FindFirstChild("HumanoidRootPart")
            if otherhumanoid and otherhrp and otherhumanoid.Health > 0 then
                local distance = (otherhrp.Position - root.Position).Magnitude
                if distance < closestDistance then
                    closestDistance = distance
                    closestRoot = otherhrp
                end
            end
        end
    end
    if closestRoot then
        return closestDistance, closestRoot
    end
    return nil, nil
end

local function RemoteEvent(args)
	coms:FireServer(unpack(args))
end

local function HideHotbarSel(tool)
	local success, err = pcall(function()
		local gui = player.PlayerGui.Hotbar.Backpack.Hotbar[MoveTable[tool]].Base.Overlay
		gui.Visible = false
	end)
	if not success then
		warn("Could not hide hotbar selector: " .. tostring(err))
	end
end

--== Sounds ==--

function Sounds.Play(soundId, looped, volume, waitForEnd)
    local sound = Instance.new("Sound")
    sound.SoundId = soundId
    sound.Looped = looped or false
    sound.Volume = volume or 0.5
    sound.Parent = SoundService
    
    sound:Play()
    
    -- Wait for sound to finish if waitForEnd is true and not looped
    if waitForEnd and not looped then
        sound.Ended:Wait()
        sound:Destroy()
    elseif not looped then
        -- Destroy after it ends if not waiting
        sound.Ended:Connect(function()
            sound:Destroy()
        end)
    end
    
    return sound
end

function Sounds.PlaySequence(sounds, waitBetween, overlapTime)
    task.spawn(function()
        for i, soundData in ipairs(sounds) do
            -- Handle both string format and table format
            local soundId
            if type(soundData) == "string" then
                soundId = soundData
            else
                soundId = soundData[1] or soundData.id
            end
            
            local looped = type(soundData) == "table" and (soundData[2] or soundData.looped) or false
            local volume = type(soundData) == "table" and (soundData[3] or soundData.volume) or 0.5
            local waitForEnd = type(soundData) == "table" and (soundData[4] or soundData.waitForEnd) or false
            
            local sound = Sounds.Play(soundId, looped, volume, false)
            
            -- If waitBetween is true, wait for this sound to finish before playing next
            if waitBetween and not looped and i < #sounds then
                -- Wait for sound to load its length
                while sound.TimeLength == 0 do
                    task.wait()
                end
                
                -- Calculate wait time with overlap
                local overlap = overlapTime or 0 -- Default no overlap
                local waitTime = math.max(0, sound.TimeLength - overlap)
                
                task.wait(waitTime)
            end
        end
    end)
end

function Sounds.Ravage(Full)
    if Full then
        Sounds.PlaySequence({SoundTable.Ravage1, SoundTable.Ravage2, SoundTable.Ravage3}, true)
    else
        Sounds.Play(SoundTable.Ravage1)
    end
end

function Sounds.SwiftSweep()
    Sounds.Play(SoundTable.SwiftSweep)
end

function Sounds.CollaRuin()
    Sounds.PlaySequence({SoundTable.CollaRuin1, SoundTable.CollaRuin2}, true)
end

function Sounds.SpiralStorm(Full)
    if Full then
        Sounds.Play(SoundTable.SpiralStorm1)
    else
        Sounds.Play(SoundTable.SpiralStorm2)
    end
end

function Sounds.StoicBomb()
    Sounds.PlaySequence({SoundTable.StoicBombCharge, SoundTable.StoicBombVoiceline, SoundTable.StoicBombExplode}, true)
end

function Sounds.Dropkick202020(Full)
    if Full then
        Sounds.PlaySequence({SoundTable.CutsceneMusic202020, SoundTable.CamSfx202020, SoundTable.GuiSfx202020}, true, 5)
    else
        Sounds.PlaySequence({SoundTable.StartSong202020, SoundTable.RunSfx202020}, false)
    end
end

function Sounds.FlexWorks()
    Sounds.PlaySequence({SoundTable.FlexWorksSfx, SoundTable.FlexWorksMusic, SoundTable.FlexWorksVoiceline}, false)
    Sounds.Play(SoundTable.FlexWorksHit)
end

--== Animations ==--

function Animations.Play(animationId, speed, looped, customstart, priority, waitForEnd)
    if priority then
        for _, track in ipairs(animator:GetPlayingAnimationTracks()) do
            track:Stop()
        end
    end
    local animation = Instance.new("Animation")
    animation.AnimationId = animationId
    local track = animator:LoadAnimation(animation)
    track.Looped = looped or false
    if priority then
        track.Priority = Enum.AnimationPriority.Action4
    end
    if speed then
        track:Play(0.1, 1, speed)
    else
        track:Play()
    end
    if customstart then
        RunService.Heartbeat:Wait()
        track.TimePosition = customstart
    end
    
    -- Wait for animation to finish if waitForEnd is true
    if waitForEnd then
        track.Stopped:Wait()
    end
    
    return track
end

function Animations.PlaySequence(animations, priority)
	sequenceTask = task.spawn(function()
		for _, animData in ipairs(animations) do
			if stopanim == false then
				-- Handle both array format {animId, speed, duration} and table format
				local animId
				if type(animData) == "string" then
					animId = animData
				else
					animId = animData[1] or animData.id
				end
				
				local speed = type(animData) == "table" and (animData[2] or animData.speed) or 1
				local duration = type(animData) == "table" and (animData[3] or animData.duration) or nil

				local track = Animations.Play(animId, speed, false, nil, priority)
				if not track then return end

				if duration then
					task.wait(duration)
					track:Stop()
				else
					track.Stopped:Wait()
				end
			end
		end
	end)
end

local BlackList = (function()
    local blacklistedAnimations = {}
    local isMonitoring = false
    return function(animationId)
        local cleanId = tostring(animationId):gsub("rbxassetid://", "")
        if not table.find(blacklistedAnimations, cleanId) then
            table.insert(blacklistedAnimations, cleanId)
            print("[KJ] [BLACKLISTED]", cleanId)
        end
        if not isMonitoring then
            isMonitoring = true
            RunService.Heartbeat:Connect(function()
                for _, track in ipairs(animator:GetPlayingAnimationTracks()) do
                    local trackId = tostring(track.Animation.AnimationId):gsub("rbxassetid://", "")
                    if table.find(blacklistedAnimations, trackId) then
                        track:Stop()
                        print("[KJ] [STOPPED]", trackId)
                    end
                end
            end)
        end
    end
end)()

--== Tools ==--

function Tools.Backup()
	local fbp = player:FindFirstChild("fbp")
	if not fbp then
		fbp = Instance.new("Folder")
		fbp.Name = "fbp"
		fbp.Parent = player
	end
	for _, tool in ipairs(backpack:GetChildren()) do
		if tool:IsA("Tool") or tool:IsA("HopperBin") then
			toolReferences[tool.Name] = tool
			local clone = tool:Clone()
			clone.Parent = fbp
            print("[KJ] Successfully Backed up " .. tool.Name .. "!")
		end
	end
end

function Tools.Remove()
    for i,v in pairs(backpack:GetDescendants()) do
        if v:IsA('Tool') or v:IsA('HopperBin') then
            v:Destroy()
        end
    end
    for i,v in pairs(char:GetDescendants()) do
        if v:IsA('Tool') or v:IsA('HopperBin') then
            v:Destroy()
        end
    end
end

function Tools.Restore(player)
    for _, tool in ipairs(fbp:GetChildren()) do
        if tool:IsA("Tool") or tool:IsA("HopperBin") then
			tool.Parent = backpack
            print("[KJ] Successfully Restored " .. tool.Name .. "!")
		end
    end
end

function Tools.UseMove(Name)
    if backpack:FindFirstChild(Name) then
        local args = {
            {
                Tool = game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild(Name),
                Goal = "Console Move",
                ToolName = Name
            }
        }
        game:GetService("Players").LocalPlayer.Character:WaitForChild("Communicate"):FireServer(unpack(args))
    else
        warn("[KJ] Couldn't find Tool: " .. Name .. "!")
    end
end

function Tools.AddTool(name)
    local tool = Instance.new("Tool")
	tool.Name = name or "NewTool"
	tool.RequiresHandle = false
	tool.CanBeDropped = false
	tool.Parent = backpack

	tool.Equipped:Connect(function()
        HideHotbarSel(tool.Name)
		wait(0.1)
		if Movesets[name] then
            Movesets[name]()
        end
	end)
	tool.Unequipped:Connect(function()
        HideHotbarSel(tool.Name)
		wait(0.1)
		if not char:FindFirstChildOfClass("Tool") then
			if Movesets[name] then
                Movesets[name]()
            end
		end
	end)
end

--== Movesets ==--

function Movesets.Ravage()
    local nearestpos, nearestroot = getNearestCharacter()
    if not nearestroot then
        warn("[KJ] No target found!")
        return
    end
    print("Distance:", nearestpos)
    print("Target:", nearestroot)
    if nearestpos and nearestpos <= 5 then
        Sounds.Ravage(true)
        local lookDirection = nearestroot.CFrame.LookVector
        local behindPosition50 = nearestroot.Position - (lookDirection * 1.5)
        local duration = 1.90
        local startTime = tick()
        local conn
        Tools.UseMove("Crowd Buster")
        hum.WalkSpeed = 0
        Animations.PlaySequence({AnimateTable.Ravage1, AnimateTable.Ravage2}, true)
        conn = RunService.Heartbeat:Connect(function(dt)
            if tick() - startTime >= duration then
                conn:Disconnect()
                return
            end
            if nearestroot and nearestroot.Parent then
                lookDirection = nearestroot.CFrame.LookVector
                behindPosition50 = nearestroot.Position - (lookDirection * 1.5)
                root.CFrame = CFrame.new(behindPosition50, nearestroot.Position)
            else
                conn:Disconnect()
            end
        end)
        hum.WalkSpeed = 16
    else
        Sounds.Ravage()
        hum.WalkSpeed = 0
        Animations.Play(AnimateTable.Ravage1, 1, false, nil, false, true)
        hum.WalkSpeed = 16
    end
end

--== Main ==--

local function Start()
    local args = {
		{
			Goal = "Change Character",
			Character = "Monster"
		}
	}
	RemoteEvent(args)
    wait()
    Tools.Backup()
    Tools.Remove()
    Tools.AddTool("Ravage")
    Tools.Restore()
end

CreateDebugUI()
Start()