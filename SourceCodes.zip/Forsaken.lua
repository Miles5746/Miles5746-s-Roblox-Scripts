local AnimationLib = loadstring(game:HttpGet("https://raw.githubusercontent.com/Miles5746/Criminality22/refs/heads/main/AnimationChanger.luau"))()
local Fluent = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()

local AnimationPacks = {
    ["Slasher"] = {
        Idle = "rbxassetid://113858918486677",
        Walk = "rbxassetid://109054312609768",
        Run = "rbxassetid://109054312609768"
    },
    ["c00l kidd"] = {
        Idle = "rbxassetid://103606489040338",
        Walk = "rbxassetid://103108206614856",
        Run = "rbxassetid://103108206614856"
    },
    ["John Doe"] = {
        Idle = "rbxassetid://104072580597361",
        Walk = "rbxassetid://81193817424328",
        Run = "rbxassetid://132653655520682"
    },
    ["Noli"] = {
        Idle = "rbxassetid://83465205704188",
        Walk = "rbxassetid://109700476007435",
        Run = "rbxassetid://117451341682452"
    },
    ["1x1x1x1"] = {
        Idle = "rbxassetid://138754221537146",
        Walk = "rbxassetid://109130982296927",
        Run = "rbxassetid://106485518413331"
    },
    ["Nosferatu"] = {
        Idle = "rbxassetid://70639889347646",
        Walk = "rbxassetid://125580704385106",
        Run = "rbxassetid://82983377044738"
    }
}

local currentAnimationPack = nil

local function SetAnimation(packName)
    if currentAnimationPack then
        currentAnimationPack:Stop()
        currentAnimationPack = nil
    end

    local player = game:GetService("Players").LocalPlayer
    local character = player.Character or player.CharacterAdded:Wait()
    local humanoid = character:FindFirstChildOfClass("Humanoid")

    if not humanoid then return end

    local pack = AnimationPacks[packName]
    if not pack then return end

    currentAnimationPack = AnimationLib.PlayPack(
        20,
        pack.Idle,
        pack.Walk,
        pack.Run
    )
end

local function StopAllAnimations()
    if currentAnimationPack then
        currentAnimationPack:Stop()
        currentAnimationPack = nil
    end
    AnimationLib.StopAll()
end

local Window = Fluent:CreateWindow({
    Title = "Animation Changer",
    SubTitle = "by Noli",
    TabWidth = 160,
    Size = UDim2.fromOffset(580, 460),
    Acrylic = true,
    Theme = "Dark",
    MinimizeKey = Enum.KeyCode.LeftControl
})

local Tabs = {
    Animations = Window:AddTab({ Title = "Animations", Icon = "venetian-mask" }),
}

Tabs.Animations:AddButton({
    Title = "Stop All Animations",
    Description = "Stop all currently playing animations",
    Callback = function()
        StopAllAnimations()
    end
})

for name, _ in pairs(AnimationPacks) do
    Tabs.Animations:AddButton({
        Title = name,
        Description = "Set your animations to "..name.."'s style",
        Callback = function()
            SetAnimation(name)
        end
    })
end

game:GetService("Players").LocalPlayer.CharacterAdded:Connect(function(character)
    if currentAnimationPack then
        task.wait(1)
        for name, pack in pairs(AnimationPacks) do
            if currentAnimationPack and name == lastSelectedPack then
                SetAnimation(name)
                break
            end
        end
    end
end)
